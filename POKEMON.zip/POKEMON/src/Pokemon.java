public class Pokemon {
    // Attributs
    private int numeroNational;
    private String nom;
    private String type;
    private String typeSecondaire;
    private int niveau;
    private int pointsDeVie;
    private int attaque;
    private int defense;
    private int attaqueSpeciale;
    private int defenseSpeciale;
    private int vitesse;

    // Constructeur
    public Pokemon(int numeroNational, String nom, String type, String typeSecondaire, int niveau, int pointsDeVie, int attaque, int defense, int attaqueSpeciale, int defenseSpeciale, int vitesse) {
        this.numeroNational = numeroNational;
        this.nom = nom;
        this.type = type;
        this.typeSecondaire = typeSecondaire;
        this.niveau = niveau;
        this.pointsDeVie = pointsDeVie;
        this.attaque = attaque;
        this.defense = defense;
        this.attaqueSpeciale = attaqueSpeciale;
        this.defenseSpeciale = defenseSpeciale;
        this.vitesse = vitesse;
    }

    // Getters et setters pour les attribut
    public int getNumeroNational() {
        return numeroNational;
    }
    public void setNumeroNational(int numeroNational) {
        this.numeroNational = numeroNational;
    }

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }

    public String getTypeSecondaire() {
        return typeSecondaire;
    }
    public void setTypeSecondaire(String typeSecondaire) {
        this.typeSecondaire = typeSecondaire;
    }

    public int getNiveau() {
        return niveau;
    }
    public void setNiveau(int niveau) {
        this.niveau = niveau;
    }

    public int getPointsDeVie() {
        return pointsDeVie;
    }
    public void setPointsDeVie(int pointsDeVie) {
        this.pointsDeVie = pointsDeVie;
    }

    public int getAttaque() {
        return attaque;
    }
    public void setAttaque(int attaque) {
        this.attaque = attaque;
    }

    public int getDefense() {
        return defense;
    }
    public void setDefense(int defense) {
        this.defense = defense;
    }

    public int getAttaqueSpeciale() {
        return attaqueSpeciale;
    }
    public void setAttaqueSpeciale(int attaqueSpeciale) {
        this.attaqueSpeciale = attaqueSpeciale;
    }

    public int getDefenseSpeciale() {
        return defenseSpeciale;
    }
    public void setDefenseSpeciale(int defenseSpeciale) {
        this.defenseSpeciale = defenseSpeciale;
    }

    public int getVitesse() {
        return vitesse;
    }
    public void setVitesse(int vitesse) {
        this.vitesse = vitesse;
    }

    // Utilisation de la methode toString()
    @Override
    public String toString() {
        return "Pokemon {" +
                "Numéro National=" + numeroNational +
                ", Nom='" + nom + '\'' +
                ", Type='" + type + '\'' +
                (typeSecondaire != null ? ", Type Secondaire='" + typeSecondaire + '\'' : "") +
                ", Niveau=" + niveau +
                ", Points de Vie=" + pointsDeVie +
                ", Attaque=" + attaque +
                ", Défense=" + defense +
                ", Attaque Spéciale=" + attaqueSpeciale +
                ", Défense Spéciale=" + defenseSpeciale +
                ", Vitesse=" + vitesse +
                '}';
    }

    // Calculer les dommages infligés en utilisant la formule donnée :
    public int calculerDommage(Pokemon adversaire, int puissance) {

        double dommage = (((2.0 * this.niveau + 10) / 250) * ((double) this.attaque / adversaire.getDefense()) * puissance) + 2;
        return (int) dommage; // Retourne les dommages sous forme d'entier
    }

    // Bonus : Determination de qui attaque en premier
    public static Pokemon premierAttaque(Pokemon p1, Pokemon p2) {
        return (p1.getVitesse() > p2.getVitesse()) ? p1 : p2;
    }
}
