public class Main {
    public static void main(String[] args) {
        // Création des Pokemons
        Pokemon Mehdi = new Pokemon(90, "Mehdi", "Eau", null, 500, 100, 75, 35, 65, 40, 35);
        Pokemon Nizar = new Pokemon(72, "Nizar", "Feu", null, 50, 120, 49, 49, 65, 65, 45);


        System.out.println(Mehdi);
        System.out.println(Nizar);


        int puissance = 50; // Puissance d'attaque
        int dommagesMehdi = Mehdi.calculerDommage(Nizar, puissance);
        System.out.println("Mehdi inflige " + dommagesMehdi + " points de dégâts à Nizar.");


        int dommagesNizar = Nizar.calculerDommage(Mehdi, puissance);
        System.out.println("Nizar inflige " + dommagesNizar + " points de dégâts à Mehdi.");


        Pokemon premier = Pokemon.premierAttaque(Mehdi, Nizar);
        System.out.println(premier.getNom() + " attaque en premier !");
    }
}
